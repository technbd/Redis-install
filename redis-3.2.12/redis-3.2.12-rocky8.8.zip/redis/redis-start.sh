redis-server /redis/redis-3.2.12/redis.conf

