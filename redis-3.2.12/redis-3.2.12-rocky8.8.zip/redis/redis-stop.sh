kill -9 $(pgrep redis-server)

