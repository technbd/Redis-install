export REDIS_HOME=/redis/redis-3.2.12
export PATH=$REDIS_HOME/src:$PATH

